**Off-topic channels**

There are three off-topic channels:  
• <#291284109232308226>  
• <#463035241142026251>  
• <#463035268514185226>  

Their names change randomly every 24 hours, but you can always find them under the `OFF-TOPIC/GENERAL` category in the channel list.

Please read our [off-topic etiquette](https://pythondiscord.com/pages/resources/guides/off-topic-etiquette/) before participating in conversations.
